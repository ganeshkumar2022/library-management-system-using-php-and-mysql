<nav class="navbar navbar-expand-md bg-white" style="color:black;border-bottom:2px solid black;">
  <!-- Brand -->
  <a class="navbar-brand" href="#"><img src="images/logo.png" style="height:80px;"></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav" style="margin-left:300px;">
      <li class="nav-item">
        <a class="nav-link text-dark" href="index.php">HOME</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="index.php">USER LOGIN</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="signup.php">USER SIGNUP</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="alogin.php">ADMIN LOGIN</a>
      </li>
    </ul>
  </div>
</nav>